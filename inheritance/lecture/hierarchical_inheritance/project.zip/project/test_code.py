from project.dog import Dog
from project.cat import Cat

d = Dog()
c = Cat()
print(d.eat())
print(c.eat())
print(d.bark())
print(c.meow())